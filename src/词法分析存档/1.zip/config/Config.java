package config;

import utils.IOUtils;

import java.io.IOException;
import java.io.PrintStream;



public class Config {
    /**
     * The path of files.
     */
    public static String fileInPath = "testfile.txt";
    public static String fileOutPath = "output.txt";
    public static String stdOutPath = "stdout.txt";
    /**
     * stages of compilation
     */
    public static boolean lexer = true;

    public static void init() throws IOException {
        IOUtils.clear(fileOutPath);
        System.setOut(new PrintStream(stdOutPath));
    }
}
