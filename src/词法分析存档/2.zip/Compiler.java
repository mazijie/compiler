import config.Config;
import LexicalAnalyzer.LexicalAnalyzer;
import utils.IOUtils;

import java.io.IOException;

public class Compiler {
    public static void main(String[] args) {
        try {
            Config.init();
            LexicalAnalyzer.getInstance().analyze(IOUtils.read(Config.fileInPath));
            LexicalAnalyzer.getInstance().printLexAns();
        }catch (IOException e) {
            System.out.println("Error(IO):" + e);
        }
        catch (Exception e) {
            System.out.println("Error:" + e.getMessage());
        }

    }
}